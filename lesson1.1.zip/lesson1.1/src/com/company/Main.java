package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("Hello world!!!");
        System.out.println((1+2)-4*3/2);
        System.out.println(7+1);
        System.out.println("result"+(7+88));

        int ageOfnumberStudent;//объявление пременной
        ageOfnumberStudent=7;//объявление пременной

        int ageOfperson=22;
        System.out.println(ageOfperson);
        System.out.println(ageOfperson+"возраст человека");
        System.out.println(ageOfperson+7);
        ageOfperson=30;//переопределение значения пременной
        System.out.println(ageOfperson);

        boolean isItNight=true;
        System.out.println(isItNight);

        double digit=7.89;

        final int NUM=8;//неизменимая переменная (константа)



        }



    }

